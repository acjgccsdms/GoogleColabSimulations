def say_hi():
    return "Hello"

def say_no():
    return "NOOOOO"

def say_yes():
    return "Yes"

def cool():
    return "cool"